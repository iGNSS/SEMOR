#!/bin/sh
# rtkrcv startup script

echo statup script ok

